﻿namespace WindowsFormsApp1.Properties
{
    internal class ins
    {
    }
}